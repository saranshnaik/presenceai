package com.nophubbing.presenceai.storage

import android.content.Context
import android.util.Log
import java.io.File

/**
 * CSVLogger — appends BehaviorSignal rows to presence_log.csv.
 */
object CSVLogger {

    private const val TAG = "CSVLogger"
    private const val CSV_FILE = "presence_log.csv"

    private val HEADER = "timestamp,userId,dayNumber,hourOfDay,isEveningSession," +
        "baselineUnlocksPerHour,baselineSessionDurationS,baselineNotifGapS," +
        "unlockCountPerHour,microSessionDurationS,notifToUnlockGapS," +
        "behaviorDriftScore,timePhaseRisk,voiceActivityDetected," +
        "peopleNearbyCount,vadConfidenceScore,btSignalStrength,label"

    fun writeRow(
        context: Context,
        timestamp: Long,
        userId: Int,
        dayNumber: Int,
        hourOfDay: Int,
        isEveningSession: Int,
        baselineUnlocksPerHour: Double,
        baselineSessionDurationS: Double,
        baselineNotifGapS: Double,
        unlockCountPerHour: Double,
        microSessionDurationS: Double,
        notifToUnlockGapS: Double,
        behaviorDriftScore: Double,
        timePhaseRisk: Double,
        voiceActivityDetected: Int,
        peopleNearbyCount: Int,
        vadConfidenceScore: Double,
        btSignalStrength: Double,
        label: Double = -1.0
    ) {
        try {
            val file = File(context.filesDir, CSV_FILE)
            if (!file.exists()) {
                file.writeText("$HEADER\n")
            }
            val row = "$timestamp,$userId,$dayNumber,$hourOfDay,$isEveningSession," +
                "$baselineUnlocksPerHour,$baselineSessionDurationS,$baselineNotifGapS," +
                "$unlockCountPerHour,$microSessionDurationS,$notifToUnlockGapS," +
                "$behaviorDriftScore,$timePhaseRisk,$voiceActivityDetected," +
                "$peopleNearbyCount,$vadConfidenceScore,$btSignalStrength,$label\n"
            file.appendText(row)
        } catch (e: Exception) {
            Log.e(TAG, "writeRow failed: ${e.message}")
        }
    }
}
