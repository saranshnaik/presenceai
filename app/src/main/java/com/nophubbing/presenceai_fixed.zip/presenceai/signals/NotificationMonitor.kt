package com.nophubbing.presenceai.signals

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * NotificationMonitor — NotificationListenerService that tracks notification arrival times.
 * Registered in AndroidManifest with BIND_NOTIFICATION_LISTENER_SERVICE permission.
 */
class NotificationMonitor : NotificationListenerService() {

    companion object {
        /** Timestamp (ms) of the last notification received. 0 if none. */
        @Volatile
        var lastNotificationTimeMs: Long = 0L
            private set

        private const val TAG = "NotificationMonitor"
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        // Ignore our own notifications
        if (sbn.packageName == "com.nophubbing.presenceai") return
        lastNotificationTimeMs = System.currentTimeMillis()
        Log.v(TAG, "Notification posted from ${sbn.packageName}")
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // Could track dismissal for PostNudgeObserver, but handled there directly
    }
}
