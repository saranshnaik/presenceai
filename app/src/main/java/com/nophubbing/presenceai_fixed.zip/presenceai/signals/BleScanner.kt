package com.nophubbing.presenceai.signals

import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat

/**
 * BleScanner — scans for nearby BLE devices to detect social presence.
 * Requires BLUETOOTH_SCAN (Android 12+) or ACCESS_FINE_LOCATION (< 12).
 */
class BleScanner(private val context: Context) {

    private val TAG = "BleScanner"

    @Volatile private var nearbyCount = 0
    private var scanner: BluetoothLeScanner? = null
    private var scanning = false

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            // Only count devices with signal strength above -90 dBm (nearby)
            if (result.rssi > -90) {
                nearbyCount = 1  // Binary: at least one device nearby
            }
        }
        override fun onScanFailed(errorCode: Int) {
            Log.w(TAG, "BLE scan failed: $errorCode")
        }
    }

    /** Returns 1 if at least one nearby BLE device was detected, 0 otherwise. */
    fun getPeopleNearbyCount(): Int {
        if (!hasPermission()) return 0
        startScanIfNeeded()
        return nearbyCount
    }

    /** Resets the nearby count (call each heartbeat cycle). */
    fun resetNearbyCount() {
        nearbyCount = 0
    }

    private fun startScanIfNeeded() {
        if (scanning) return
        try {
            val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
            if (!adapter.isEnabled) return
            scanner = adapter.bluetoothLeScanner ?: return
            scanner?.startScan(scanCallback)
            scanning = true
        } catch (e: Exception) {
            Log.e(TAG, "startScan failed: ${e.message}")
        }
    }

    fun stopScan() {
        try {
            scanner?.stopScan(scanCallback)
        } catch (_: Exception) {}
        scanning = false
    }

    private fun hasPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_SCAN) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
        }
    }
}
