package com.nophubbing.presenceai.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * PresenceColors — all brand colors for the Presence AI app.
 */
object PresenceColors {

    // ── Backgrounds ──────────────────────────────────────────────────────────
    val BgDeep        = Color(0xFF0A0E1A)   // deep navy background
    val BgCard        = Color(0xFF131929)   // slightly lighter card surface
    val BgElevated    = Color(0xFF1C2436)   // elevated panels

    // ── Brand / Accent ────────────────────────────────────────────────────────
    val AccentCyan    = Color(0xFF00D4FF)   // primary accent
    val AccentGreen   = Color(0xFF00E5A0)   // positive / presence high
    val AccentAmber   = Color(0xFFFFC947)   // warning / medium risk
    val AccentRed     = Color(0xFFFF5252)   // danger / high risk

    // ── Presence Score gradient endpoints ────────────────────────────────────
    val ScoreHigh     = AccentGreen
    val ScoreMid      = AccentAmber
    val ScoreLow      = AccentRed

    // ── Text ─────────────────────────────────────────────────────────────────
    val TextPrimary   = Color(0xFFE8EAF0)
    val TextSecondary = Color(0xFF8A94AB)
    val TextHint      = Color(0xFF4A5568)

    // ── Borders / Dividers ───────────────────────────────────────────────────
    val BorderSubtle  = Color(0x1AFFFFFF)   // 10% white
    val BorderMid     = Color(0x33FFFFFF)   // 20% white

    // ── Utility ──────────────────────────────────────────────────────────────
    val Transparent   = Color(0x00000000)

    /** Maps a presence score (0–100) to a colour. */
    fun scoreColor(score: Float): Color = when {
        score >= 70f -> ScoreHigh
        score >= 40f -> ScoreMid
        else         -> ScoreLow
    }
}
