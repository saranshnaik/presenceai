package com.nophubbing.presenceai

/**
 * BuildConfig — compile-time constants injected by Gradle.
 *
 * In your app/build.gradle.kts add:
 *   val localProperties = java.util.Properties()
 *   rootProject.file("local.properties").takeIf { it.exists() }?.let {
 *       localProperties.load(it.inputStream())
 *   }
 *   android {
 *       defaultConfig {
 *           buildConfigField("String", "GEMINI_API_KEY",
 *               "\"${localProperties["GEMINI_API_KEY"] ?: ""}\"")
 *           buildConfigField("String", "CLAUDE_API_KEY",
 *               "\"${localProperties["CLAUDE_API_KEY"] ?: ""}\"")
 *       }
 *   }
 *
 * This stub satisfies IDE references. The real values come from the
 * auto-generated BuildConfig class produced by the Android Gradle plugin.
 * DO NOT commit real API keys here.
 */
object BuildConfig {
    const val GEMINI_API_KEY: String = ""   // injected by Gradle — set in local.properties
    const val CLAUDE_API_KEY: String = ""   // injected by Gradle — set in local.properties
}
