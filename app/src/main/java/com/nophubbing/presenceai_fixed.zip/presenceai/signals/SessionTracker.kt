package com.nophubbing.presenceai.signals

import android.content.Context
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.util.Log

/**
 * SessionTracker — queries UsageStatsManager for app session counts.
 */
class SessionTracker(private val context: Context) {

    /**
     * Returns a Pair of (totalSessions, microSessions) within the given window.
     * @param windowMs  Observation window in milliseconds (e.g. 30_000 for 30s)
     */
    fun getMicroSessionStats(windowMs: Long = 30_000L): Pair<Int, Int> {
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val start = now - windowMs

            val events = usm.queryEvents(start, now)
            val event = UsageEvents.Event()
            var totalSessions = 0
            var microSessions = 0
            var sessionStart = 0L
            var currentPkg: String? = null

            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                when (event.eventType) {
                    UsageEvents.Event.MOVE_TO_FOREGROUND -> {
                        currentPkg = event.packageName
                        sessionStart = event.timeStamp
                    }
                    UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                        if (currentPkg != null && sessionStart > 0) {
                            val dur = event.timeStamp - sessionStart
                            if (dur > 500) {
                                totalSessions++
                                if (dur in 1000..20_000) microSessions++
                            }
                        }
                        currentPkg = null
                        sessionStart = 0L
                    }
                }
            }
            Pair(totalSessions, microSessions)
        } catch (e: Exception) {
            Log.e("SessionTracker", "getMicroSessionStats failed: ${e.message}")
            Pair(0, 0)
        }
    }
}
