package com.nophubbing.presenceai.storage

import android.content.Context
import android.util.Log
import com.nophubbing.presenceai.ml.SignalRow
import java.io.File

/**
 * CSVReader — reads the on-device presence_log.csv and parses it into SignalRow objects.
 * Companion to CSVLogger. Column order must match CSVLogger.writeRow().
 *
 * CSV columns (index → field):
 *  0  timestamp, 1 userId, 2 dayNumber, 3 hourOfDay, 4 isEveningSession,
 *  5  baselineUnlocksPerHour, 6 baselineSessionDurationS, 7 baselineNotifGapS,
 *  8  unlockCountPerHour, 9 microSessionDurationS, 10 notifToUnlockGapS,
 *  11 behaviorDriftScore, 12 timePhaseRisk, 13 voiceActivityDetected,
 *  14 peopleNearbyCount, 15 vadConfidenceScore, 16 btSignalStrength, 17 label
 */
object CSVReader {

    private const val TAG = "CSVReader"
    private const val CSV_FILE = "presence_log.csv"

    fun readAllAsSignalRows(context: Context): List<SignalRow> {
        val file = File(context.filesDir, CSV_FILE)
        if (!file.exists()) {
            Log.d(TAG, "No CSV file found at ${file.absolutePath}")
            return emptyList()
        }

        val rows = mutableListOf<SignalRow>()
        try {
            file.forEachLine { line ->
                if (line.isBlank() || line.startsWith("timestamp")) return@forEachLine
                val cols = line.split(",")
                if (cols.size < 18) return@forEachLine
                try {
                    rows.add(
                        SignalRow(
                            timestamp                = cols[0].toLongOrNull()  ?: 0L,
                            userId                   = cols[1].toIntOrNull()   ?: 1,
                            dayNumber                = cols[2].toIntOrNull()   ?: 1,
                            hourOfDay                = cols[3].toIntOrNull()   ?: 0,
                            isEveningSession         = cols[4].toIntOrNull()   ?: 0,
                            baselineUnlocksPerHour   = cols[5].toDoubleOrNull() ?: 3.6,
                            baselineSessionDurationS = cols[6].toDoubleOrNull() ?: 52.0,
                            baselineNotifGapS        = cols[7].toDoubleOrNull() ?: 21.1,
                            unlockCountPerHour       = cols[8].toDoubleOrNull() ?: 0.0,
                            microSessionDurationS    = cols[9].toDoubleOrNull() ?: 0.0,
                            notifToUnlockGapS        = cols[10].toDoubleOrNull() ?: 0.0,
                            behaviorDriftScore       = cols[11].toDoubleOrNull() ?: 0.0,
                            timePhaseRisk            = cols[12].toDoubleOrNull() ?: 0.0,
                            voiceActivityDetected    = cols[13].toIntOrNull()   ?: 0,
                            peopleNearbyCount        = cols[14].toIntOrNull()   ?: 0,
                            vadConfidenceScore       = cols[15].toDoubleOrNull() ?: 0.0,
                            btSignalStrength         = cols[16].toDoubleOrNull() ?: 0.0,
                            label                    = cols[17].toDoubleOrNull() ?: -1.0
                        )
                    )
                } catch (e: Exception) {
                    Log.w(TAG, "Skipping malformed row: $line — ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "readAllAsSignalRows failed: ${e.message}")
        }
        return rows
    }

    fun getRowCount(context: Context): Int {
        val file = File(context.filesDir, CSV_FILE)
        if (!file.exists()) return 0
        return file.readLines().count { it.isNotBlank() && !it.startsWith("timestamp") }
    }
}
