package com.nophubbing.presenceai.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.nophubbing.presenceai.analytics.FeatureExtractor
import com.nophubbing.presenceai.analytics.SignalAggregator
import com.nophubbing.presenceai.analytics.SignalRepository
import kotlinx.coroutines.*

/**
 * MonitoringService — Foreground service that continuously gathers behavioral signals
 * and publishes them to SignalRepository every 30 seconds.
 *
 * This is the primary data-collection service, separate from PresenceService
 * (which houses the full Heartbeat nudge-delivery loop).
 */
class MonitoringService : Service() {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)

    private lateinit var featureExtractor: FeatureExtractor
    private lateinit var signalAggregator: SignalAggregator

    companion object {
        private const val CHANNEL_ID = "monitoring_service_channel"
        private const val NOTIFICATION_ID = 2
        private const val POLL_INTERVAL_MS = 30_000L
    }

    override fun onCreate() {
        super.onCreate()
        featureExtractor = FeatureExtractor(this)
        signalAggregator = SignalAggregator(this)
        startForeground(NOTIFICATION_ID, buildNotification())
        startMonitoringLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
    }

    private fun startMonitoringLoop() {
        serviceScope.launch(Dispatchers.IO) {
            while (isActive) {
                try {
                    val features = featureExtractor.extractFeatures(windowMinutes = 10)
                    val signals  = signalAggregator.generateSignals(features)
                    SignalRepository.update(signals)
                } catch (e: Exception) {
                    // Silent — never crash the service
                }
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Presence AI Monitoring",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Presence AI")
            .setContentText("Monitoring your presence habits")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
    }
}
