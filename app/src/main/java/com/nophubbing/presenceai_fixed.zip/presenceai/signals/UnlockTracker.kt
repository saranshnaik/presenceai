package com.nophubbing.presenceai.signals

import android.content.Context
import android.content.SharedPreferences

/**
 * UnlockTracker — tracks device unlock events via SharedPreferences.
 * UnlockCount is incremented by NotificationMonitor (or a KeyguardReceiver).
 */
class UnlockTracker(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("unlock_tracker", Context.MODE_PRIVATE)

    /** Returns the number of unlocks in the last 10 minutes. */
    fun getUnlocksLast10Min(): Int {
        val now = System.currentTimeMillis()
        val windowStart = now - 10 * 60_000L
        val timestamps = loadTimestamps()
        val recent = timestamps.filter { it > windowStart }
        // Prune old entries
        saveTimestamps(recent)
        return recent.size
    }

    /** Call this each time a screen-unlock event is detected. */
    fun recordUnlock() {
        val now = System.currentTimeMillis()
        val list = loadTimestamps().toMutableList()
        list.add(now)
        // Keep only last 30 minutes to avoid unbounded growth
        val pruned = list.filter { it > now - 30 * 60_000L }
        saveTimestamps(pruned)
    }

    private fun loadTimestamps(): List<Long> {
        val raw = prefs.getString("unlock_ts", "") ?: return emptyList()
        if (raw.isBlank()) return emptyList()
        return raw.split(",").mapNotNull { it.toLongOrNull() }
    }

    private fun saveTimestamps(list: List<Long>) {
        prefs.edit().putString("unlock_ts", list.joinToString(",")).apply()
    }
}
