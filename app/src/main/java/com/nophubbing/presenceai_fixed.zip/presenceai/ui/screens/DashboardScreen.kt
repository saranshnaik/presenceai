package com.nophubbing.presenceai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nophubbing.presenceai.analytics.BehaviorSignals
import com.nophubbing.presenceai.analytics.SignalRepository
import com.nophubbing.presenceai.ui.theme.PresenceColors
import kotlin.math.roundToInt

/**
 * DashboardScreen — main Compose UI showing the live presence score
 * and key behavioral signal metrics.
 */
@Composable
fun DashboardScreen() {
    val signals by SignalRepository.latestSignals.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Text(
            text       = "Presence AI",
            color      = PresenceColors.TextPrimary,
            fontSize   = 28.sp,
            fontWeight = FontWeight.Bold
        )

        // Presence Score Card
        PresenceScoreCard(signals)

        // Signal cards row
        signals?.let { s ->
            Row(
                modifier            = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    label  = "Unlocks",
                    value  = "${s.rawUnlocks}",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    label  = "Sessions",
                    value  = "${s.totalSessions}",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    label  = "Micro",
                    value  = "${s.microSessions}",
                    modifier = Modifier.weight(1f)
                )
            }

            // Social context
            Row(
                modifier            = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    label  = "Voice",
                    value  = if (s.voiceActivityDetected > 0) "Detected" else "None",
                    color  = if (s.voiceActivityDetected > 0) PresenceColors.AccentAmber else PresenceColors.TextSecondary,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    label  = "Nearby",
                    value  = if (s.peopleNearbyCount > 0) "Yes" else "No",
                    color  = if (s.peopleNearbyCount > 0) PresenceColors.AccentAmber else PresenceColors.TextSecondary,
                    modifier = Modifier.weight(1f)
                )
            }
        } ?: run {
            Text(
                text     = "Waiting for signal data…",
                color    = PresenceColors.TextSecondary,
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
private fun PresenceScoreCard(signals: BehaviorSignals?) {
    val score = signals?.presenceScore ?: 100f
    val color = PresenceColors.scoreColor(score)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(16.dp),
        colors   = CardDefaults.cardColors(containerColor = PresenceColors.BgCard)
    ) {
        Column(
            modifier            = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text     = "Presence Score",
                color    = PresenceColors.TextSecondary,
                fontSize = 14.sp
            )
            Text(
                text       = "${score.roundToInt()}",
                color      = color,
                fontSize   = 64.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text     = when {
                    score >= 70f -> "You're present ✓"
                    score >= 40f -> "Slightly distracted"
                    else         -> "High distraction risk"
                },
                color    = color,
                fontSize = 15.sp
            )
        }
    }
}

@Composable
private fun MetricCard(
    label:    String,
    value:    String,
    color:    Color    = PresenceColors.TextPrimary,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape    = RoundedCornerShape(12.dp),
        colors   = CardDefaults.cardColors(containerColor = PresenceColors.BgCard)
    ) {
        Column(
            modifier            = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = label, color = PresenceColors.TextSecondary, fontSize = 12.sp)
            Text(text = value, color = color, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
