package com.nophubbing.presenceai.ml

// SignalRow is defined in Schema.kt — this file is intentionally empty.
// Keeping the file avoids breaking any external tooling that references it by path.
