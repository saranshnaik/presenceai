package com.nophubbing.presenceai.ml

import android.util.Log

/**
 * RuleBasedClassifier — heuristic phubbing detection.
 *
 * 7-feature indices (FeatureEngineering.kt):
 *   [0] x1 unlock_freq          [0,4]   normalised unlock rate
 *   [1] x2 micro_session_ratio  [0,1]   fraction of sessions < 20s
 *   [2] x3 notif_reflex         {0,1}   unlocked within 60s of notif
 *   [3] x4 behavior_drift_z     [-3,3]  z-score vs personal baseline
 *   [4] x5 time_phase           {0,1}   1 = evening / night
 *   [5] x6 vad_energy           {0,1}   voice activity detected
 *   [6] x7 ble_social           {0,1}   BLE device(s) nearby
 *
 * Score contract:
 *   idle alone          → presenceScore ≥ 95%
 *   BLE nearby only     → presenceScore ≥ 93%  (earbuds / laptop don't count as phubbing)
 *   voice + BLE present → score drops with behaviour
 *   active phubbing     → presenceScore ≤ 40%
 */
object RuleBasedClassifier {

    private const val TAG = "RuleBasedClassifier"

    @Volatile private var lastPPhub: Double = 0.0
    @Volatile private var nudgeConfirmationSteps: Int = 0

    private fun softStep(x: Double, center: Double, steepness: Double): Double =
        1.0 / (1.0 + Math.exp(-steepness * (x - center)))

    // ── P(drift): pure behavioural signal, no social ──────────────────────────
    fun computePDrift(features: List<Double>): Double {
        val unlockFreq  = features.getOrElse(0) { 0.0 }  // [0,4]
        val microRatio  = features.getOrElse(1) { 0.0 }  // [0,1]
        val notifReflex = features.getOrElse(2) { 0.0 }  // {0,1}
        val driftZ      = features.getOrElse(3) { 0.0 }  // [-3,3]

        // Drift z-score: slightly increased (0.15) for better usage detection
        val driftWeight  = softStep(driftZ, 0.75, 4.0).coerceAtLeast(0.0) * 0.15

        // Unlock rate: increased (0.12) as requested
        val unlockWeight = (Math.atan(unlockFreq / 3.0) / (Math.PI / 2.0)) * 0.12

        // Micro sessions: increased (0.10) as requested
        val microWeight  = microRatio * 0.10

        // Notification reflex: slightly increased (0.04)
        val reflexWeight = if (notifReflex > 0.5) 0.04 else 0.0

        // NO base floor — truly idle = 0
        val pDrift = (driftWeight + unlockWeight + microWeight + reflexWeight).coerceIn(0.0, 1.0)

        Log.v(TAG, "pDrift=${"%.3f".format(pDrift)} " +
            "[drift=${driftWeight.format()} unlock=${unlockWeight.format()} " +
            "micro=${microWeight.format()} reflex=${reflexWeight.format()}]")
        return pDrift
    }

    // ── P(phub): pDrift × social context amplifier ────────────────────────────
    fun computePPhub(features: List<Double>): Double {
        val pDrift        = computePDrift(features)
        val isEvening     = features.getOrElse(4) { 0.0 } > 0.5
        val voiceAmp      = features.getOrElse(5) { 0.0 }.coerceIn(0.0, 1.0)
        val blePresent    = features.getOrElse(6) { 0.0 } > 0.5
        val socialPresent = voiceAmp > 0.01 || blePresent

        val pPhub: Double
        if (socialPresent) {
            // Continuous scaling based on voice intensity (amplitude)
            val voiceWeight = voiceAmp.coerceIn(0.0, 1.0)
            
            // Multiplier: scales from base (1.6 for BLE) up to peak (5.5 for Voice+BLE)
            // Reduced "just a little" as requested
            val baseMult    = 1.6
            val targetMax   = if (blePresent) 5.1 else 3.6
            val currentMult = baseMult + (voiceWeight * (targetMax - baseMult))
            
            // Baseline: slightly reduced scaling (0.02 to 0.04)
            val currentBaseline = 0.02 + (voiceWeight * 0.02)

            val evening = if (isEvening) 1.08 else 1.0
            pPhub = (currentBaseline + (pDrift * currentMult * evening)).coerceIn(0.0, 1.0)
        } else {
            // Alone — strong attenuation
            pPhub = (pDrift * 0.10).coerceIn(0.0, 1.0)
        }

        // EMA smoothing α=0.5 — faster decay than before so it doesn't get stuck
        val smoothed = (pPhub * 0.50) + (lastPPhub * 0.50)
        lastPPhub = smoothed

        Log.d(TAG, "pDrift=${"%.3f".format(pDrift)} social=$socialPresent " +
            "voiceAmp=${"%.3f".format(voiceAmp)} ble=$blePresent → pPhub=${"%.3f".format(smoothed)}" +
            " presenceScore=${"%.1f".format((1.0 - smoothed) * 100)}%")
        return smoothed
    }

    // ── shouldNudge: 3 consecutive steps above threshold ─────────────────────
    fun shouldNudge(pPhub: Double, threshold: Double): Boolean {
        val t = threshold.coerceAtLeast(PipelineConfig.NUDGE_THRESHOLD.toDouble())
        if (pPhub >= t) nudgeConfirmationSteps++ else nudgeConfirmationSteps = 0
        val confirmed = nudgeConfirmationSteps >= 3
        if (confirmed) {
            nudgeConfirmationSteps = 0
            Log.d(TAG, "Nudge CONFIRMED pPhub=${"%.3f".format(pPhub)}")
        }
        return confirmed
    }

    fun reset() { lastPPhub = 0.0; nudgeConfirmationSteps = 0 }

    private fun Double.format() = "%.3f".format(this)
}
