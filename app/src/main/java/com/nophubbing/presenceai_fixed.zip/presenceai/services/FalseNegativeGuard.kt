package com.nophubbing.presenceai.services

import android.util.Log
import com.nophubbing.presenceai.ml.PipelineConfig

/**
 * FalseNegativeGuard — prevents the nudge system from going silent for too long.
 *
 * If no nudge has fired in SILENCE_THRESHOLD_MS despite consistently elevated
 * pPhub readings, the guard resets the nudge confirmation counter so the next
 * qualifying reading can fire immediately.
 */
object FalseNegativeGuard {

    private const val TAG = "FalseNegativeGuard"
    private const val SILENCE_THRESHOLD_MS = 5 * 60_000L  // 5 minutes
    private const val MIN_AVG_PPHUB_TO_GUARD = 0.45f

    @Volatile private var lastNudgeFiredMs: Long = 0L
    private val recentPPhubValues = ArrayDeque<Float>(20)

    /** Call this every heartbeat cycle with the current pPhub reading. */
    fun onCycle(pPhub: Float): Boolean {
        val now = System.currentTimeMillis()
        recentPPhubValues.addLast(pPhub)
        if (recentPPhubValues.size > 20) recentPPhubValues.removeFirst()
        if (recentPPhubValues.size < 6) return false
        val silenceDuration = now - lastNudgeFiredMs
        if (silenceDuration < SILENCE_THRESHOLD_MS) return false
        val avgPPhub = recentPPhubValues.average().toFloat()
        if (avgPPhub < MIN_AVG_PPHUB_TO_GUARD) return false
        Log.w(TAG, "FalseNegativeGuard triggered — silence=${silenceDuration / 1000}s avgPPhub=${"%.3f".format(avgPPhub)}")
        return true
    }

    /** Call this whenever a nudge is actually delivered. */
    fun onNudgeFired() {
        lastNudgeFiredMs = System.currentTimeMillis()
        recentPPhubValues.clear()
        Log.d(TAG, "Nudge fired — guard reset")
    }

    fun reset() {
        lastNudgeFiredMs = 0L
        recentPPhubValues.clear()
    }
}
