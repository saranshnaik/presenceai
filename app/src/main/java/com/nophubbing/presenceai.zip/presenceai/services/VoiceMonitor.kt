package com.nophubbing.presenceai.services

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import java.io.File

/**
 * VoiceMonitor — binary VAD (Voice Activity Detection).
 * Uses MediaRecorder.maxAmplitude to detect human speech in the background.
 */
class VoiceMonitor(private val context: Context) {

    private var recorder: MediaRecorder? = null

    /**
     * Samples audio for 1.5 seconds. 
     * Returns:
     *   1  if amplitude > threshold (voice detected)
     *   0  if below threshold (silence or quiet background)
     *  -1  if permission denied or error
     */
    fun detectVoice(): Int {
        val tempFile = File(context.cacheDir, "voice_sample.3gp")
        
        return try {
            recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
                setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                setOutputFile(tempFile.absolutePath)

                prepare()
                start()
            }

            // Sample for 1.5 seconds to capture speech patterns
            Thread.sleep(1500)

            val amplitude = recorder?.maxAmplitude ?: 0
            stopRecording()

            if (tempFile.exists()) tempFile.delete()

            // Threshold 2500 is sensitive enough for normal speech at 0.5-1m
            if (amplitude > 2500) {
                Log.d("PresenceAI", "VAD: Voice detected (amp=$amplitude)")
                1
            } else {
                Log.d("PresenceAI", "VAD: No voice (amp=$amplitude)")
                0
            }

        } catch (e: Exception) {
            Log.e("PresenceAI", "VAD failed: ${e.message}")
            stopRecording()
            if (tempFile.exists()) tempFile.delete()
            -1
        }
    }

    private fun stopRecording() {
        try {
            recorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) {
            // ignore
        }
        recorder = null
    }
}
